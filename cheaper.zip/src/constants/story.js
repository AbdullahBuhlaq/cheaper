export const defaultSecondStory = ["../images/user.webp", "../images/user.webp", "../images/user.webp"];
export const defaultStory = ["images/user.webp", "images/user.webp", "images/user.webp"];
