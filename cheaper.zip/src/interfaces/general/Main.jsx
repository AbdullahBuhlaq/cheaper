function Main(props) {
  try {
    return <>hello page1</>;
  } catch (error) {
    console.log(error);
  }
}

export default Main;
