function Contact(props) {
  try {
    return <>Contact</>;
  } catch (err) {
    console.log(err);
  }
}

export default Contact;
