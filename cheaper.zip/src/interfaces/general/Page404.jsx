function Page404(props) {
  try {
    return <>404 not found</>;
  } catch (err) {
    console.log(err);
  }
}

export default Page404;
