function AboutUs(props) {
  try {
    return <>AboutUs</>;
  } catch (err) {
    console.log(err);
  }
}

export default AboutUs;
