function Services(props) {
  try {
    return <>services</>;
  } catch (err) {
    console.log(err);
  }
}

export default Services;
